package t;

import java.sql.ResultSet;
import java.sql.SQLException;

public class test {
	public static void main(String[] args) throws SQLException {
		DBOper dbOper = new DBOper();
		dbOper.getConn("localhost","user","root","");
		String sql = "SELECT count(*) FROM user.company where companyname=\"Sun\"";
		ResultSet executeQuery = dbOper.executeQuery(sql, null);
		executeQuery.next();
		int int1 = executeQuery.getInt(1);
		System.out.println(int1);
	}
}
